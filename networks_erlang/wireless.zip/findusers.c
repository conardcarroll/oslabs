#include <stdio.h>
#include <stdlib.h>


double erlang(double A, int C) {
	double B = 0;
	double invB = 1;
	int i = 1;
	for(;i <= C; i++){
		invB = 1.0 + invB * (double)i / A;	
		printf("i %d Pb = %f %% \n", i, invB * 100.0);	
	}
	
	B = 1.0f / invB;
	printf("Pb = %f %% \n", B * 100.0);
	return B;
}

int main(int argc, char* argv[])
{
	// 1 calculate Pb
	// 2 number of blocked calls
	// 3 number of recalled
	// 4 new offered traffic
	// 5 recurse
	int channels = 100;
	double users = 2.0;
	double gos = 0.05;
	double blockedCalls = 0.01;
	double recall = 0.5;
	double acceptable = 0.02;
	double A = 0.0;
	double p = 0.0;
	double result = 1;
	double currentResult = 0;
	double newTraffic = 0;
	
	blockedCalls = users * blockedCalls;
	recall = blockedCalls * recall;
	users = users + recall;
	printf("result %f\n", users);
	
	return 0;
}
